﻿using System.Linq;
using System.IO;
using System;

namespace LogAnonyserGUI {
    class CSV {
        private string[] data = null;
        private int numberOfRows;
        private int numberOfCols;

        /// <summary>
        /// Indicates if a CSV file is correctly opened
        /// </summary>
        public bool Opened {
            get => data != null;
        }

        /// <summary>
        /// The number of rows into the CSV
        /// </summary>
        public int NumberOfRows {
            get => numberOfRows;
        }

        /// <summary>
        /// The number of columns into the CSV
        /// </summary>
        public int NumberOfColumns {
            get => numberOfCols;
        }

        /// <summary>
        /// Default constructor
        /// </summary>
        /// <param name="path">If not null, the file at the specified path will be opened if possible</param>
        /// <param name="french">If true, then we are using ';' as the separator instead of ','</param>
        public CSV(string path = null, bool french = false) {
            if (path != null)
                LoadContent(File.ReadAllText(path), french);
        }

        /// <summary>
        /// Load a CSV file into memory
        /// </summary>
        /// <param name="path">The path of the file to open</param>
        /// <param name="french">If true, then we are using ';' as the separator instead of ','</param>
        public void Open(string path, bool french = false) {
            try {
                LoadContent(File.ReadAllText(path), french);
            } catch (FileNotFoundException) {
                Console.WriteLine("The file " + path + " does not exists!");
            } catch (UnauthorizedAccessException) {
                Console.WriteLine("Can not access to the file " + path);
            }
        }

        /// <summary>
        /// Save the in-memory representation of the CSV into a file
        /// </summary>
        /// <param name="path">The path of the output file</param>
        public void Save(string path) {
            // Instantiating output string
            string output = "";

            // Converting the matrix representation into a string one
            for (int i = 0 ; i < numberOfRows ; ++i) {
                for (int j = 0 ; j < numberOfCols ; ++j) {
                    output += data[i * (numberOfRows - 1) + j];

                    if (j < numberOfCols - 1)
                        output += ',';
                }

                output += '\n';
            }

            // Saving the file
            try {
                File.WriteAllText(path, output);
            } catch (DirectoryNotFoundException) {
                Console.WriteLine("Can not create file " + path + " in an unexistant directory!");
            } catch (UnauthorizedAccessException) {
                Console.WriteLine("Can not create file " + path + " without an administrator authorization");
            }
        }

        /// <summary>
        /// Retrieves an element of the CSV matrix
        /// </summary>
        /// <param name="row">The row of the element</param>
        /// <param name="col">The column of the element</param>
        /// <returns>The value of the element or null, if the index does not exist</returns>
        public string Get(int row, int col) {
            return row >= numberOfRows || col >= numberOfCols ? null : data[row * (numberOfRows - 1) + col];
        }

        /// <summary>
        /// Retrieves an element of a labeled column
        /// </summary>
        /// <param name="field">The name of the label</param>
        /// <param name="index">The index into the labeled column</param>
        /// <returns>The value of the element or null, if the index does not exist</returns>
        public string Get(string field, int index) {
            if (index >= numberOfRows)
                return null;

            int selectedCol = -1;

            // Looking for the correct column
            for (int i = 0 ; i < numberOfCols ; ++i) {
                if (data[i].Equals(field)) {
                    selectedCol = i;
                    break;
                }
            }

            // Header not found
            if (selectedCol == -1)
                return null;

            return data[(index + 1) * (numberOfRows - 1) + selectedCol];
        }

        /// <summary>
        /// Sets the value of an element in the CSV matrix
        /// </summary>
        /// <param name="row">The row of the element</param>
        /// <param name="col">The column of the element</param>
        /// <param name="value">The new value of the element</param>
        /// <returns>true if the change is made, false otherwise</returns>
        public bool Set(int row, int col, string value) {
            if (row >= numberOfRows || col >= numberOfCols)
                return false;

            data[row * (numberOfRows - 1) + col] = value;
            return true;
        }

        /// <summary>
        /// Sets the value of an element in a labeled column of the CSV matrix
        /// </summary>
        /// <param name="field">The name of the label</param>
        /// <param name="index">The index of the element in the column</param>
        /// <param name="value">The new value of the element</param>
        /// <returns>true if the change is made, false otherwise</returns>
        public bool Set(string field, int index, string value) {
            if (index >= numberOfRows)
                return false;

            int selectedCol = -1;

            // Looking for the correct column
            for (int i = 0 ; i < numberOfCols ; ++i) {
                if (data[i].Equals(field)) {
                    selectedCol = i;
                    break;
                }
            }

            // Header not found
            if (selectedCol == -1)
                return false;

            data[(index + 1) * (numberOfRows - 1) + selectedCol] = value;
            return true;
        }

        /// <summary>
        /// Load the content of a raw CSV into memory
        /// </summary>
        /// <param name="raw">The raw CSV unformated</param>
        /// <param name="french">If true, then we are using ';' as the separator instead of ','</param>
        private void LoadContent(string raw, bool french = false) {
            // Splitting the lines
            string[] rows = raw.Split('\n');

            // Retrieving the number of rows
            numberOfRows = rows.Length;

            // First row is expected to be the headers row
            string[] headers = rows[0].Split(french ? ';' : ',');
            numberOfCols = headers.Length;

            // Retrieving all the data
            data = new string[numberOfRows * numberOfCols];
            for (int i = 0 ; i < numberOfRows ; ++i) {
                string[] tmp = rows[i].Split(',');
                for (int j = 0 ; j < numberOfCols ; ++j) {
                    data[i * (numberOfRows - 1) + j] = tmp[j];
                }
            }
        }
    }
}
