﻿using System.Security.Cryptography;
using System.Windows.Forms;
using System.ComponentModel;
using System.Text;
using System;

namespace LogAnonyserGUI {
    public partial class LogAnonyser : Form {
        public LogAnonyser() {
            InitializeComponent();
        }

        private void InputFileButton_Click(object sender, EventArgs e) {
            InputFileDialog.ShowDialog();
        }

        private void InputFilePath_Click(object sender, EventArgs e) {
            InputFileDialog.ShowDialog();
        }

        private void InputFileDialog_FileOk(object sender, CancelEventArgs e) {
            InputFilePath.Text = InputFileDialog.FileName;
        }

        private void OutputFileButton_Click(object sender, EventArgs e) {
            OutputFileDialog.ShowDialog();
        }

        private void OutputFilePath_Click(object sender, EventArgs e) {
            OutputFileDialog.ShowDialog();
        }

        private void OutputFileDialog_FileOk(object sender, CancelEventArgs e) {
            OutputFilePath.Text = OutputFileDialog.FileName;
        }

        private void Anonymise_Click(object sender, EventArgs e) {
            if (!InputFileDialog.CheckPathExists) {
                MessageBox.Show("Unknown input file!", "Unable to anonymise", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            // Checking if the seed is given
            if (Seed.Text.Length == 0 || Seed.Text.Equals("")) {
                MessageBox.Show("You must specify a salt for the cipher!", "Unable to anonymise", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            // Checking if the field is given
            if (Field.Text.Length == 0 || Field.Text.Equals("")) {
                MessageBox.Show("You must specify the field to anonymise!", "Unable to anonymise", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            // Opening the CSV
            CSV file = new CSV(InputFileDialog.FileName, UseFrenchNotation.Checked);
            if (!file.Opened) {
                MessageBox.Show("Unable to open your input file!", "Unable to anonymise", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            // Setting the hashing environment
            SHA256 hash = SHA256.Create();

            // Hashing all the instances in the column
            for (int index = 0 ; index < file.NumberOfRows - 1 ; ++index) {
                string inputString = file.Get(Field.Text, index);
                if (inputString == null) {
                    Console.WriteLine("Unknown field name!");
                    return;
                }

                // If the input string is not empty or just a space
                if (inputString.Length > 0 && !inputString.Equals(" ")) {
                    // We're adding the seed and start the hash
                    byte[] outputBuffer = hash.ComputeHash(Encoding.UTF8.GetBytes(Seed.Text + inputString));

                    // Then, we save the hash into the CSV file
                    file.Set(Field.Text, index, ByteArrayToString(outputBuffer));
                }
            }

            // Saving the file
            file.Save(OutputFileDialog.FileName);

            MessageBox.Show("Your file is anonymised!", "Anonymisation successful!", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        /// <summary>
        /// Convert a byte array into an alphanumeric representation
        /// </summary>
        /// <param name="array">The array to convert</param>
        /// <returns>The hexadecimal representation of the byte array</returns>
        private static string ByteArrayToString(byte[] array) {
            string output = "";

            // For each byte in the array, we retrieve its hexadecimal representation
            foreach (byte b in array)
                output += string.Format("{0:x2}", b);

            return output;
        }
    }
}
