﻿namespace LogAnonyserGUI {
    partial class LogAnonyser {
        /// <summary>
        /// Variable nécessaire au concepteur.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Nettoyage des ressources utilisées.
        /// </summary>
        /// <param name="disposing">true si les ressources managées doivent être supprimées ; sinon, false.</param>
        protected override void Dispose(bool disposing) {
            if (disposing && (components != null)) {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Code généré par le Concepteur Windows Form

        /// <summary>
        /// Méthode requise pour la prise en charge du concepteur - ne modifiez pas
        /// le contenu de cette méthode avec l'éditeur de code.
        /// </summary>
        private void InitializeComponent() {
            this.InputFileDialog = new System.Windows.Forms.OpenFileDialog();
            this.OutputFileDialog = new System.Windows.Forms.SaveFileDialog();
            this.flowLayoutPanel1 = new System.Windows.Forms.FlowLayoutPanel();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.InputFilePath = new System.Windows.Forms.TextBox();
            this.button1 = new System.Windows.Forms.Button();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.OutputFileButton = new System.Windows.Forms.Button();
            this.OutputFilePath = new System.Windows.Forms.TextBox();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.UseFrenchNotation = new System.Windows.Forms.CheckBox();
            this.button2 = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.Seed = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.Field = new System.Windows.Forms.TextBox();
            this.flowLayoutPanel1.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.groupBox3.SuspendLayout();
            this.SuspendLayout();
            // 
            // InputFileDialog
            // 
            this.InputFileDialog.DefaultExt = "*.csv";
            this.InputFileDialog.Filter = "CSV files|*.csv";
            this.InputFileDialog.FileOk += new System.ComponentModel.CancelEventHandler(this.InputFileDialog_FileOk);
            // 
            // OutputFileDialog
            // 
            this.OutputFileDialog.DefaultExt = "*.csv";
            this.OutputFileDialog.Filter = "CSV files|*.csv";
            this.OutputFileDialog.FileOk += new System.ComponentModel.CancelEventHandler(this.OutputFileDialog_FileOk);
            // 
            // flowLayoutPanel1
            // 
            this.flowLayoutPanel1.Controls.Add(this.groupBox1);
            this.flowLayoutPanel1.Controls.Add(this.groupBox2);
            this.flowLayoutPanel1.Controls.Add(this.groupBox3);
            this.flowLayoutPanel1.Controls.Add(this.button2);
            this.flowLayoutPanel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.flowLayoutPanel1.Location = new System.Drawing.Point(0, 0);
            this.flowLayoutPanel1.Name = "flowLayoutPanel1";
            this.flowLayoutPanel1.Size = new System.Drawing.Size(689, 283);
            this.flowLayoutPanel1.TabIndex = 0;
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.InputFilePath);
            this.groupBox1.Controls.Add(this.button1);
            this.groupBox1.Location = new System.Drawing.Point(3, 3);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(680, 57);
            this.groupBox1.TabIndex = 0;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Input File";
            // 
            // InputFilePath
            // 
            this.InputFilePath.Location = new System.Drawing.Point(9, 22);
            this.InputFilePath.Name = "InputFilePath";
            this.InputFilePath.ReadOnly = true;
            this.InputFilePath.Size = new System.Drawing.Size(584, 20);
            this.InputFilePath.TabIndex = 1;
            this.InputFilePath.Click += new System.EventHandler(this.InputFilePath_Click);
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(599, 19);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(75, 23);
            this.button1.TabIndex = 0;
            this.button1.Text = "Open";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.InputFileButton_Click);
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.OutputFileButton);
            this.groupBox2.Controls.Add(this.OutputFilePath);
            this.groupBox2.Location = new System.Drawing.Point(3, 66);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(680, 52);
            this.groupBox2.TabIndex = 1;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Output File";
            // 
            // OutputFileButton
            // 
            this.OutputFileButton.Location = new System.Drawing.Point(599, 16);
            this.OutputFileButton.Name = "OutputFileButton";
            this.OutputFileButton.Size = new System.Drawing.Size(75, 23);
            this.OutputFileButton.TabIndex = 2;
            this.OutputFileButton.Text = "Save";
            this.OutputFileButton.UseVisualStyleBackColor = true;
            this.OutputFileButton.Click += new System.EventHandler(this.OutputFileButton_Click);
            // 
            // OutputFilePath
            // 
            this.OutputFilePath.Location = new System.Drawing.Point(9, 19);
            this.OutputFilePath.Name = "OutputFilePath";
            this.OutputFilePath.ReadOnly = true;
            this.OutputFilePath.Size = new System.Drawing.Size(584, 20);
            this.OutputFilePath.TabIndex = 2;
            this.OutputFilePath.Click += new System.EventHandler(this.OutputFilePath_Click);
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.Field);
            this.groupBox3.Controls.Add(this.label2);
            this.groupBox3.Controls.Add(this.Seed);
            this.groupBox3.Controls.Add(this.label1);
            this.groupBox3.Controls.Add(this.UseFrenchNotation);
            this.groupBox3.Location = new System.Drawing.Point(3, 124);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(680, 125);
            this.groupBox3.TabIndex = 2;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "Other Options";
            // 
            // UseFrenchNotation
            // 
            this.UseFrenchNotation.AutoSize = true;
            this.UseFrenchNotation.Location = new System.Drawing.Point(9, 88);
            this.UseFrenchNotation.Name = "UseFrenchNotation";
            this.UseFrenchNotation.Size = new System.Drawing.Size(152, 17);
            this.UseFrenchNotation.TabIndex = 0;
            this.UseFrenchNotation.Text = "Use French CSV notation?";
            this.UseFrenchNotation.UseVisualStyleBackColor = true;
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(3, 255);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(680, 23);
            this.button2.TabIndex = 4;
            this.button2.Text = "Anonymise";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.Anonymise_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(9, 26);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(71, 13);
            this.label1.TabIndex = 1;
            this.label1.Text = "Cypher Seed:";
            // 
            // Seed
            // 
            this.Seed.Location = new System.Drawing.Point(87, 26);
            this.Seed.Name = "Seed";
            this.Seed.Size = new System.Drawing.Size(587, 20);
            this.Seed.TabIndex = 2;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(9, 63);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(98, 13);
            this.label2.TabIndex = 3;
            this.label2.Text = "Field to Anonymise:";
            // 
            // Field
            // 
            this.Field.Location = new System.Drawing.Point(113, 60);
            this.Field.Name = "Field";
            this.Field.Size = new System.Drawing.Size(561, 20);
            this.Field.TabIndex = 4;
            // 
            // LogAnonyser
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoSize = true;
            this.ClientSize = new System.Drawing.Size(689, 283);
            this.Controls.Add(this.flowLayoutPanel1);
            this.MaximumSize = new System.Drawing.Size(705, 322);
            this.MinimumSize = new System.Drawing.Size(705, 322);
            this.Name = "LogAnonyser";
            this.Text = "LogAnonyser (GUI)";
            this.flowLayoutPanel1.ResumeLayout(false);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.OpenFileDialog InputFileDialog;
        private System.Windows.Forms.SaveFileDialog OutputFileDialog;
        private System.Windows.Forms.FlowLayoutPanel flowLayoutPanel1;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.TextBox InputFilePath;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.Button OutputFileButton;
        private System.Windows.Forms.TextBox OutputFilePath;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.CheckBox UseFrenchNotation;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.TextBox Seed;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox Field;
        private System.Windows.Forms.Label label2;
    }
}

