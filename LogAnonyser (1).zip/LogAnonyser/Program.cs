﻿using System.Security.Cryptography;
using System.Text;
using System;

namespace LogAnonyser {
    public class Program {
        /// <summary>
        /// Entry point of the application
        /// </summary>
        /// <param name="args">The lauching arguments</param>
        public static void Main(string[] args) {
            string input = null;
            string output = null;
            string seed = null;
            string field = null;
            bool french = false;

            // Retrieving arguments
            for (int i = 0 ; i < args.Length ; i += 2) {
                if (args[i].Equals("-i") || args[i].Equals("--input")) {
                    input = args[i + 1];
                } else if (args[i].Equals("-o") || args[i].Equals("--output")) {
                    output = args[i + 1];
                } else if (args[i].Equals("-s") || args[i].Equals("--seed")) {
                    seed = args[i + 1];
                } else if (args[i].Equals("-f") || args[i].Equals("--field")) {
                    field = args[i + 1];
                } else if (args[i].Equals("--french")) {
                    french = true;
                    --i;
                } else if (args[i].Equals("--help")) {
                    Help();
                    return;
                } else {
                    // Displaying help and quit
                    Console.WriteLine("Unknown argument!");
                    Help();

                    return;
                }
            }

            // Checking if all arguments are specified
            if (input == null || output == null || seed == null || field == null) {
                // Showing the error, displaying help and quit
                Console.WriteLine("Missing argument!");
                Help();

                return;
            }

            // Loading CSV file
            CSV file = new CSV(input, french);
            if (!file.Opened)
                return;

            // Setting the hashing environment
            SHA256 hash = SHA256.Create();

            // Hashing all the instances in the column
            for (int index = 0 ; index < file.NumberOfRows - 1 ; ++index) {
                string inputString = file.Get(field, index);
                if (inputString == null) {
                    Console.WriteLine("Unknown field name!");
                    return;
                }

                // If the input string is not empty or just a space
                if (inputString.Length > 0 && !inputString.Equals(" ")) {
                    // We're adding the seed and start the hash
                    byte[] outputBuffer = hash.ComputeHash(Encoding.UTF8.GetBytes(seed + inputString));

                    // Then, we save the hash into the CSV file
                    file.Set(field, index, ByteArrayToString(outputBuffer));
                }
            }

            // Saving the file
            file.Save(output);
        }

        /// <summary>
        /// Help of the application
        /// </summary>
        private static void Help() {
            Console.WriteLine("Usage: LogAnonyser.exe -i inputFile -o outputFile -s cypherSeed -f fieldName [--french]");
            Console.WriteLine();
            Console.WriteLine("Options:");
            Console.WriteLine(" -i, --input\tpath to the log file to anonyse");
            Console.WriteLine(" -o, --output\tpath of the output file");
            Console.WriteLine(" -s, --seed\tseed to use for the cypher");
            Console.WriteLine(" -f, --field\tcolumn name of the log file to anonyse");
            Console.WriteLine(" --french\tset the CSV cell separator to ;");
        }

        /// <summary>
        /// Convert a byte array into an alphanumeric representation
        /// </summary>
        /// <param name="array">The array to convert</param>
        /// <returns>The hexadecimal representation of the byte array</returns>
        private static string ByteArrayToString(byte[] array) {
            string output = "";

            // For each byte in the array, we retrieve its hexadecimal representation
            foreach (byte b in array)
                output += string.Format("{0:x2}", b);

            return output;
        }
    }
}
